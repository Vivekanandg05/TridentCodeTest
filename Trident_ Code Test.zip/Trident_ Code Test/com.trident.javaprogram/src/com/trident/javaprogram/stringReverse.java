package com.trident.javaprogram;

	public class stringReverse {
	    public static void main(String[] args) 
	    { 
	        String input = "Trident"; 
	  
	        char[] string = input.toCharArray(); 
	  
	        for (int i = string.length-1; i>=0; i--) 
	            System.out.print(string[i]); 
	    } 
	} 


